/*************************************************请勿修改或删除该文件**************************************************/
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './app';
import 'antd/dist/antd.less';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
