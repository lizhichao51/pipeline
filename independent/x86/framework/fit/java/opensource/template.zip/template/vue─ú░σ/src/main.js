/*************************************************请勿修改或删除该文件**************************************************/
import { createApp } from "vue";
import App from "./App.vue";
import './assets/styles/reset.css';
import 'element-plus/dist/index.css'

createApp(App).mount("#app");
